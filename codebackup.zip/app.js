//Tiny Treasures Project 
//FutureSkills - MCSD51 March 2025 
//Author: Nilantha Hewage
//Date created: 28th June 2025

// Adding required modules
var express = require('express');
var app = express();
var session = require('express-session');
var conn = require('./dbConfig');
var bodyParser = require('body-parser');
const fs = require('fs');

console.log('The web app is starting...');

// Set up EJS as the view engine
app.set('view engine', 'ejs');
console.log('View engine set to EJS');

// Set up session middleware
app.use(session({
    secret: 'yoursecret',
    resave: true,
    saveUninitialized: true
}));
console.log('Session middleware configured');

// Handle JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
console.log('JSON and URL-encoded parsers enabled');

// Serve static files from /public
app.use('/public', express.static('public'));
console.log('Static files served from /public');

// Body parser middleware for form data
app.use(bodyParser.urlencoded({ extended: false }));
console.log('Body parser middleware configured');

// Admin authentication middleware
const isAdmin = (req, res, next) => {
    console.log('Checking admin authentication:', { loggedin: req.session.loggedin, role: req.session.role });
    if (req.session.loggedin && req.session.role === 'admin') {
        return next();
    }
    console.log('Admin authentication failed, sending error response');
    // Send a response with a button to go back to login
   res.send(`<h2 style="color: blue;">Please login to view this page!</h2>
               <a href="/login">
               <button style="margin-top: 15px; padding: 10px 20px; background-color: #1f11ea; color: white; border: none; border-radius: 5px;">Back to Login</button>
              </a>   
              `);
};

// Home route
app.get('/', function(req, res) {
    console.log('Entering / route');
    res.render('home');
    console.log('Rendered home view');
});

// Login route
app.get('/login', function(req, res) {
    console.log('Rendered login view');
    res.render('login');   
});

// Route to render Contact Us form
app.get('/contactus', (req, res) => {
    console.log('Rendered conactus view');
    res.render('contactus');
});

// Contact Us form submission route with email to admin
// This route handles the form submission from contactus.ejs
const nodemailer = require('nodemailer');
app.post('/contactus', (req, res) => {
  const { fname, lname, email, phone, message } = req.body;

  const sql = `INSERT INTO messages (fname, lname, email, phone, message) VALUES (?, ?, ?, ?, ?)`;
  const values = [fname, lname, email, phone, message];

  conn.query(sql, values, (err, result) => {
    if (err) {
      console.error('Error inserting message:', err);
      return res.status(500).send('An error occurred while submitting the form.');
    }
    console.log('Message added to the db table with ID:', result.insertId);

    // Send Email
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'tinytreasures.gleneden@gmail.com',
        pass: 'hywu svwx aftr jzhp' // gmail app password
      }
    });

    const mailOptions = {
      from: 'tinytreasures.gleneden@gmail.com',
      to: 'tinytreasures.gleneden@gmail.com',
      subject: `New Inquiry Contact Form Submission from ${fname} ${lname}`,
      text: `
You received a new contact form message:

First Name: ${fname}
Last Name: ${lname}
Email: ${email}
Phone: ${phone}

Message:
${message}
      `
    };

    transporter.sendMail(mailOptions, (emailErr, info) => {
      if (emailErr) {
        console.error('Error sending email:', emailErr);
        // Optional: still redirect but log the issue
      } else {
        console.log('Email sent:', info.response);
      }
      res.redirect('/thankyou');
    });
  });
});
// Route to render Thank You page
// This route is called after form submission
app.get('/thankyou', (req, res) => {
  res.render('thankyou');
});

// Authentication route
app.post('/auth', function(req, res) {
    console.log('Entering /auth route', req.body);
    let email = req.body.email;
    let password = req.body.password;
    if (email && password) {
        const sql = 'SELECT * FROM users WHERE email = ? AND password = ?';
        console.log('Executing query:', sql, [email, password]);
        conn.query(sql, [email, password], function(error, results, fields) {
            if (error) {
                console.error('Query error:', error);
                return res.status(500).send('Server Error');
            }
            console.log('Query result:', results);
            if (results.length > 0) {
                req.session.loggedin = true;
                req.session.email = email;
                req.session.username = results[0].username;
                req.session.role = results[0].role;
                console.log('User authenticated:', { role: results[0].role, username: results[0].username });
                res.redirect('/membersOnly');
                console.log('Redirecting to /membersOnly');
            } else {
                console.log('Authentication failed: Incorrect email/password');
                // Send a response with a button to go back to login
                res.send(`
                <h2 style="color: blue;">Incorrect Email and/or Password!</h2>
               <a href="/login">
               <button style="margin-top: 15px; padding: 10px 20px; background-color: #1f11ea; color: white; border: none; border-radius: 5px;">Back to Login</button>
              </a>
    `);
                 }
        });
    } else {
        console.log('Missing email or password');
        // res.send('<h2 style="color: blue;">Please enter Email and Password!</h2>'); 
        res.send(`
                <h2 style="color: blue;">Please enter Email and Password!</h2>
               <a href="/login">
               <button style="margin-top: 15px; padding: 10px 20px; background-color: #1f11ea; color: white; border: none; border-radius: 5px;">Back to Login</button>
              </a>   
              `);   
    }
});

// Members-only route (admin, parent or teacher)
app.get('/membersOnly', function(req, res, next) {
    console.log('Entering /membersOnly route', { loggedin: req.session.loggedin, role: req.session.role });
    if (req.session.loggedin) {
        if (req.session.role === 'admin') {
            res.render('adminOnly', { adminName: req.session.username, adminEmail: req.session.email });
            console.log('Rendered adminOnly view for admin');
            } else if (req.session.role === 'teacher') {
            const sql = 'SELECT id, first_name, last_name, gender, dob, picture, food_allergy FROM child';
            conn.query(sql, (err, child) => {
            if (err) {
                console.error('Error fetching child db data:', err);
                return res.status(500).send('Database error');
            }
            // Render the teacherOnly view with child data
            console.log('Fetched child data for teacher:', child);
            res.render('teacherOnly', { teacherName: req.session.username, teacherEmail: req.session.email, child });
            console.log('Rendered teacherOnly view for teacher with child data');
            
        });

// Render parentOnly view for parent with child and logs data (option 2 multiple children same parent)
} else if (req.session.role === 'parent') {
    const parentEmail = req.session.email;
    const selectedChildId = req.query.childId; // get from URL query, e.g. /membersOnly?childId=3

    const sql = 'SELECT * FROM child WHERE parent_email = ?';
    conn.query(sql, [parentEmail], (err, children) => {
        if (err) {
            console.error('Error fetching children:', err);
            return res.status(500).send('Database error');
        }

        let childIdToUse = selectedChildId || (children.length > 0 ? children[0].id : null);

        if (!childIdToUse) {
            // No children found
            return res.render('parentOnly', { 
                parentName: req.session.username, 
                parentEmail: parentEmail, 
                children: [], 
                logs: []
            });
        }

        const logSql = 'SELECT * FROM attendance_log WHERE child_id = ? ORDER BY date DESC';
        conn.query(logSql, [childIdToUse], (err, logs) => {
            if (err) {
                console.error('Error fetching activity logs:', err);
                return res.status(500).send('Database error');
            }
            res.render('parentOnly', { 
                parentName: req.session.username, 
                parentEmail: parentEmail, 
                children, 
                logs, 
                selectedChildId: childIdToUse
            });
        });
    });
}
    } else {
        console.log('Not logged in, sending error response');
        // Send a response with a button to go back to login
        res.send(`
                <h2 style="color: blue;">Please login to view this page!</h2>
               <a href="/login">
               <button style="margin-top: 15px; padding: 10px 20px; background-color: #1f11ea; color: white; border: none; border-radius: 5px;">Back to Login</button>
              </a>   
              `);
    }
});

// Admin Dashboard View Contact Us Messages route
const db = require('./dbConfig'); // Import the db connection
app.get('/admin/view-messages', isAdmin, (req, res) => {
  const query = "SELECT fname, lname, email, phone, message, submitted_at FROM messages ORDER BY submitted_at DESC";

  db.query(query, (err, results) => {
    if (err) {
      console.error("Query error:", err);
      res.status(500).send("Database error");
    } else {
      res.render('view-messages', { messages: results });
    }
  });
});


// Admin Dashboard View Educator Logs route
app.get('/admin/educatorLogs', isAdmin, (req, res) => {
    console.log('Entering /admin/educatorLogs route');
    const sql = `
        SELECT 
            a.*, 
            c.first_name, 
            c.last_name 
        FROM attendance_log a
        JOIN child c ON a.child_id = c.id
        ORDER BY a.date DESC
    `;

    conn.query(sql, (err, logs) => {
        if (err) {
            console.error('Error fetching attendance logs:', err);
            return res.status(500).send('Database error');
        }

        res.render('educatorLogs', { logs });
    });
});

// Admin Dashboard New Enrollments route
app.get('/admin/newEnrollments', isAdmin, (req, res) => {
    console.log('Entering /admin/newEnrollments route');
        res.render('newEnrollments')
    });

// Set up multer for file uploads to handle in New Enrollments by Admin
// This will allow image uploads for child registration
const multer = require('multer');
const path = require('path');
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './public/uploads/'); // Store in public/uploads folder
    },
    filename: (req, file, cb) => {
        const uniqueName = Date.now() + '-' + file.originalname;
        cb(null, uniqueName);
    }
});
const upload = multer({ storage: storage });

// Admin Dashboard New Enrollments POST route
app.post('/admin/newEnrollments', isAdmin, upload.single('picture'), (req, res) => {
    console.log('Entering /admin/newEnrollments POST route');
    const { first_name, last_name, gender, dob, food_allergy, parent_email, parent_first_name, parent_last_name, parent_phone } = req.body;
    const picture = req.file ? req.file.filename : null;

    if (!picture) {
        console.error('No picture uploaded');
        return res.status(400).send('Picture is required');
    }

    const sql = `
        INSERT INTO child (first_name, last_name, gender, dob, picture, food_allergy, parent_first_name, parent_last_name ,parent_email, parent_phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    conn.query(sql, [first_name, last_name, gender, dob, picture, food_allergy, parent_first_name, parent_last_name ,parent_email, parent_phone], (err, result) => {
        if (err) {
            console.error('Error inserting child record:', err);
            return res.status(500).send('Database error');
        }
        console.log('New child enrolled with ID:', result.insertId);
        res.redirect('/admin/childDetails');
    });
});

// Admin Dashboard View Child Register route
app.get('/admin/childDetails', isAdmin, (req, res) => {
    console.log('Entering /admin/childDetails route');
    const sql = 'SELECT * FROM child ORDER BY id ASC';
    conn.query(sql, (err, children) => {
        if (err) {
            console.error('Error fetching child details:', err);
            return res.status(500).send('Database error');
        }
        res.render('childRegister', { children });
        console.log('Rendered child register with details');
    });
});
// Show Edit Child Details form
// This route renders the form to edit a child's details
app.get('/admin/edit-child/:id', (req, res) => {
  const childId = req.params.id;
  const fs = require('fs');
  conn.query('SELECT * FROM child WHERE id = ?', [childId], (err, results) => {
    if (err) throw err;
    if (results.length > 0) {
      res.render('editChild', { child: results[0] });
    } else {
      res.send('Child not found.');
    }
  });
});

// Handle Child record update form with upload a a new picture
app.post('/admin/edit-child/:id', upload.single('picture'), (req, res) => {
  const childId = req.params.id;
  const {
    first_name, last_name, gender, dob, food_allergy,
    parent_first_name, parent_last_name, parent_email, parent_phone
  } = req.body;
  const newPicture = req.file ? req.file.filename : null;

  // First: Get current picture from DB
  const getPicSql = 'SELECT picture FROM child WHERE id = ?';

  conn.query(getPicSql, [childId], (err, results) => {
    if (err) throw err;

    const oldPicture = results[0].picture;

    // If a new picture is uploaded and an old one exists, delete the old one
    if (newPicture && oldPicture) {
      const oldPath = path.join(__dirname, 'public', 'uploads', oldPicture);
      fs.unlink(oldPath, (unlinkErr) => {
        if (unlinkErr) console.error('Failed to delete old image:', unlinkErr);
      });
    }

    // Update with new or existing image
    const updatedPicture = newPicture || oldPicture;

    const updateSql = `
      UPDATE child 
      SET first_name = ?, last_name = ?, gender = ?, dob = ?, food_allergy = ?, 
          parent_first_name = ?, parent_last_name = ?, parent_email = ?, parent_phone = ?, picture = ? 
      WHERE id = ?
    `;

    conn.query(updateSql, [
      first_name, last_name, gender, dob, food_allergy,
      parent_first_name, parent_last_name, parent_email, parent_phone, updatedPicture, childId
    ], (err2) => {
      if (err2) throw err2;
      res.redirect('/admin/childDetails');
    });
  });
});

// Handle Child Record delete
app.post('/admin/delete-child/:id', (req, res) => {
  const childId = req.params.id;
  conn.query('DELETE FROM child WHERE id = ?', [childId], (err) => {
    if (err) throw err;
    res.redirect('/admin/childDetails');
  });
});

// User Management route
app.get('/admin/user-management', isAdmin, (req, res) => {
    console.log('Entering /admin/user-management route');
    const sql = 'SELECT email, username, role FROM users';
    console.log('Executing query:', sql);
    conn.query(sql, (err, users) => {
        if (err) {
            console.error('Query error:', err);
            return res.status(500).send('Server Error');
        }
        console.log('Query result: Fetched users', users);
        const roles = [
            { name: 'admin' },
            { name: 'teacher' },
            { name: 'parent' }
        ];
        const error = req.query.error;
        res.render('userManagement', { users, roles, error });
        console.log('Rendered userManagement view', { error });
    });
});

// Add User route
app.post('/admin/add-user', isAdmin, (req, res) => {
    console.log('Entering /admin/add-user route', req.body);
    const { username, email, password, role } = req.body;
    if (username && email && password && role) {
        const checkSql = `SELECT email FROM users WHERE email = ?`;
        console.log('Executing check query:', checkSql, [email]);
        conn.query(checkSql, [email], (err, results) => {
            if (err) {
                console.error('Check query error:', err);
                return res.status(500).send('Server Error');
            }
            if (results.length > 0) {
                console.log('Duplicate email detected:', email);
                return res.redirect('/admin/user-management?error=duplicate');
            }
            const sql = `INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)`;
            console.log('Executing insert query:', sql, [username, email, password, role]);
            conn.query(sql, [username, email, password, role], (err, result) => {
                if (err) {
                    console.error('Insert query error:', err);
                    if (err.code === 'ER_DUP_ENTRY') {
                        console.log('Duplicate email detected (race condition):', email);
                        return res.redirect('/admin/user-management?error=duplicate');
                    }
                    return res.status(500).send('Server Error');
                }
                console.log('Query result: User added', { username, email, role });
                res.redirect('/admin/user-management');
                console.log('Redirecting to /admin/user-management');
            });
        });
    } else {
        console.log('Missing fields in add-user:', req.body);
        res.send('All fields are required!');
    }
});

// Edit User route
app.post('/admin/edit-user/:email', isAdmin, (req, res) => {
    console.log('Entering /admin/edit-user route', { email: req.params.email, body: req.body });
    const { username, role, password } = req.body;
    const email = req.params.email;
    if (username && role) {
        let sql, params;
        if (password) {
            // Update password if provided
            sql = `UPDATE users SET username = ?, role = ?, password = ? WHERE email = ?`;
            params = [username, role, password, email];
        } else {
            // Skip password update if not provided
            sql = `UPDATE users SET username = ?, role = ? WHERE email = ?`;
            params = [username, role, email];
        }
        console.log('Executing query:', sql, params);
        conn.query(sql, params, (err, result) => {
            if (err) {
                console.error('Query error:', err);
                return res.status(500).send('Server Error');
            }
            console.log('Query result: User updated', { email, username, role, passwordUpdated: !!password, affectedRows: result.affectedRows });
            res.redirect('/admin/user-management');
            console.log('Redirecting to /admin/user-management');
        });
    } else {
        console.log('Missing fields in edit-user:', req.body);
        res.send('All fields are required!');
    }
});

// Delete User route
app.get('/admin/delete-user/:email', isAdmin, (req, res) => {
    console.log('Entering /admin/delete-user route', { email: req.params.email });
    const email = req.params.email;
    const sql = `DELETE FROM users WHERE email = ?`;
    console.log('Executing query:', sql, [email]);
    conn.query(sql, [email], (err, result) => {
        if (err) {
            console.error('Query error:', err);
            return res.status(500).send('Server Error');
        }
        console.log('Query result: User deleted', { email, affectedRows: result.affectedRows });
        res.redirect('/admin/user-management');
        console.log('Redirecting to /admin/user-management');
    });
});
// Route to render teacher dashboard with child list
app.get('/teacher/dashboard', (req, res) => {
    const sql = 'SELECT id, first_name, last_name, gender, dob, picture, food_allergy FROM child';
    conn.query(sql, (err, child) => {
        if (err) {
            console.error('Error fetching child db data:', err);
            return res.status(500).send('Database Error');
        }
        // Render the teacherOnly view with child data
        res.render('teacherOnly', { child, teacherName: req.session.username, 
            teacherEmail: req.session.email // send teacherName & Email

        }); 
    });
});

// Educator adding daily activities to child
// GET route to show log form
app.get('/teacher/log-activity/:childId', (req, res) => {
    const childId = req.params.childId;
    const sql = 'SELECT * FROM child WHERE id = ?';

    conn.query(sql, [childId], (err, results) => {
        if (err) {
            console.error('Error fetching child:', err);
            return res.status(500).send('Database Error');
        }
        if (results.length === 0) {
            return res.status(404).send('Child record not found');
        }

        res.render('logActivity', { child: results[0] });
    });
});
// Educator adding daily activities to child
// GET route to show log form
app.get('/teacher/log-activity/:childId', (req, res) => {
    const childId = req.params.childId;
    const sql = 'SELECT * FROM child WHERE id = ? ORDER BY date DESC';

    conn.query(sql, [childId], (err, results) => {
        if (err) {
            console.error('Error fetching child:', err);
            return res.status(500).send('Database error');
        }
        if (results.length === 0) {
            return res.status(404).send('Child record not found');
        }

        res.render('logActivity', { child: results[0] });
    });
});

// This route add daily attendance logs for a specific child to the database
// POST route to save log activity
app.post('/teacher/log-activity/:childId', (req, res) => {
    const { in_time, out_time, activities, date } = req.body;
    const child_id = req.params.childId;  

    const sql = `
      INSERT INTO attendance_log (child_id, date, in_time, out_time, activities, date_logged)
      VALUES (?, ?, ?, ?, ?, NOW())
    `;

    conn.query(sql, [child_id, date, in_time, out_time, activities], (err, result) => {
        if (err) {
            console.error("Error saving activity log:", err);
            return res.status(500).send("Database error");
        }
        console.log("Activity log inserted successfully");
        res.redirect('/teacher/dashboard');
    });
});

// View Attendance Logs route
app.get('/teacher/view-attendance/:childId', (req, res) => {
    const childId = req.params.childId;

    const getChildQuery = 'SELECT * FROM child WHERE id = ?';
    const getLogsQuery = 'SELECT * FROM attendance_log WHERE child_id = ? ORDER BY date DESC';

    conn.query(getChildQuery, [childId], (err, childResults) => {
        if (err) {
            console.error('Error fetching child:', err);
            return res.status(500).send('Server error');
        }
        if (childResults.length === 0) {
            return res.send('Child not found');
        }

        const child = childResults[0];

        conn.query(getLogsQuery, [childId], (err, logs) => {
            if (err) {
                console.error('Error fetching attendance logs:', err);
                return res.status(500).send('Server error');
            }

            res.render('viewAttendanceLogs', { child, logs });
        });
    });
});


// Product Management route
app.get('/admin/product-management', isAdmin, (req, res) => {
    console.log('Entering /admin/product-management route');
    // Fetch products
    const productSql = 'SELECT food_id AS id, food_name AS name, price, food_type AS category FROM menu';
    console.log('Executing product query:', productSql);
    conn.query(productSql, (err, products) => {
        if (err) {
            console.error('Product query error:', err);
            return res.status(500).send('Server Error');
        }
        console.log('Query result: Fetched products', products);
        // Fetch distinct food_type values
        const typeSql = 'SELECT DISTINCT food_type FROM menu WHERE food_type IS NOT NULL';
        console.log('Executing type query:', typeSql);
        conn.query(typeSql, (err, types) => {
            if (err) {
                console.error('Type query error:', err);
                return res.status(500).send('Server Error');
            }
            const foodTypes = types.map(type => type.food_type);
            console.log('Query result: Fetched food types', foodTypes);
            const error = req.query.error;
            res.render('productManagement', { products, foodTypes, error });
            console.log('Rendered productManagement view', { error });
        });
    });
});

// Add Product route
app.post('/admin/add-product', isAdmin, (req, res) => {
    console.log('Entering /admin/add-product route', req.body);
    const { name, price, category, customCategory } = req.body;
    const finalCategory = category === 'Other' ? customCategory : category;
    if (name && price && finalCategory) {
        const checkSql = `SELECT food_name FROM menu WHERE food_name = ?`;
        console.log('Executing check query:', checkSql, [name]);
        conn.query(checkSql, [name], (err, results) => {
            if (err) {
                console.error('Check query error:', err);
                return res.status(500).send('Server Error');
            }
            if (results.length > 0) {
                console.log('Duplicate product name detected:', name);
                return res.redirect('/admin/product-management?error=duplicate');
            }
            const sql = `INSERT INTO menu (food_name, price, food_type) VALUES (?, ?, ?)`;
            console.log('Executing insert query:', sql, [name, parseFloat(price), finalCategory]);
            conn.query(sql, [name, parseFloat(price), finalCategory], (err, result) => {
                if (err) {
                    console.error('Insert query error:', err);
                    if (err.code === 'ER_DUP_ENTRY') {
                        console.log('Duplicate product name detected (race condition):', name);
                        return res.redirect('/admin/product-management?error=duplicate');
                    }
                    return res.status(500).send('Server Error');
                }
                console.log('Query result: Product added', { name, price, category: finalCategory, insertId: result.insertId });
                res.redirect('/admin/product-management');
                console.log('Redirecting to /admin/product-management');
            });
        });
    } else {
        console.log('Missing fields in add-product:', req.body);
        res.send('All fields are required!');
    }
});

// Edit Product route
app.post('/admin/edit-product/:id', isAdmin, (req, res) => {
    console.log('Entering /admin/edit-product route', { id: req.params.id, body: req.body });
    const { name, price, category, customCategory } = req.body;
    const id = req.params.id;
    const finalCategory = category === 'Other' ? customCategory : category;
    if (name && price && finalCategory) {
        const checkSql = `SELECT food_name FROM menu WHERE food_name = ? AND food_id != ?`;
        console.log('Executing check query:', checkSql, [name, id]);
        conn.query(checkSql, [name, id], (err, results) => {
            if (err) {
                console.error('Check query error:', err);
                return res.status(500).send('Server Error');
            }
            if (results.length > 0) {
                console.log('Duplicate product name detected:', name);
                return res.redirect('/admin/product-management?error=duplicate');
            }
            const sql = `UPDATE menu SET food_name = ?, price = ?, food_type = ? WHERE food_id = ?`;
            console.log('Executing update query:', sql, [name, parseFloat(price), finalCategory, id]);
            conn.query(sql, [name, parseFloat(price), finalCategory, id], (err, result) => {
                if (err) {
                    console.error('Update query error:', err);
                    if (err.code === 'ER_DUP_ENTRY') {
                        console.log('Duplicate product name detected (race condition):', name);
                        return res.redirect('/admin/product-management?error=duplicate');
                    }
                    return res.status(500).send('Server Error');
                }
                console.log('Query result: Product updated', { id, name, price, category: finalCategory, affectedRows: result.affectedRows });
                res.redirect('/admin/product-management');
                console.log('Redirecting to /admin/product-management');
            });
        });
    } else {
        console.log('Missing fields in edit-product:', req.body);
        res.send('All fields are required!');
    }
});

// Delete Product route
app.get('/admin/delete-product/:id', isAdmin, (req, res) => {
    console.log('Entering /admin/delete-product route', { id: req.params.id });
    const id = req.params.id;
    const sql = `DELETE FROM menu WHERE food_id = ?`;
    console.log('Executing query:', sql, [id]);
    conn.query(sql, [id], (err, result) => {
        if (err) {
            console.error('Query error:', err);
            return res.status(500).send('Server Error');
        }
        console.log('Query result: Product deleted', { id, affectedRows: result.affectedRows });
        res.redirect('/admin/product-management');
        console.log('Redirecting to /admin/product-management');
    });
});

// About Us page route
app.get('/aboutus', function(req, res) {
    console.log('Entering About us route');
    res.render('aboutus');
    console.log('Rendered About us view');   
});

// Contact Us route
app.get('/contactus', function(req, res) {
    console.log('Entering /contact us route');
    res.render('contactus');
    console.log('Rendered contact us view');
});

// Logout route
app.get('/logout', (req, res) => {
    console.log('Entering /logout route');
    req.session.destroy();
    res.redirect('/');
    console.log('Session destroyed, redirected to /');
});

// Start server
app.listen(3000, () => {
    console.log('Node app is running on Port 3000');
});