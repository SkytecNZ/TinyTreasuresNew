var mysql = require('mysql');
var conn = mysql.createConnection({
	host: 'localhost', 
	user: 'root',      
	password: '',    
	database: 'tinytreasures' // mysql Database name in XAMPP
}); 

conn.connect(function(err) {
	if (err) {
		console.error('Database connection failed:', err.stack);
		return;
	}
	console.log('Mysql database is connected successfully !');
});
module.exports = conn;